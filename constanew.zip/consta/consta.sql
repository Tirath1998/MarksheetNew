-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2022 at 05:48 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `consta`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roll_no` int(11) NOT NULL,
  `photo` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `education_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `student_name`, `roll_no`, `photo`, `education_id`, `created_at`, `updated_at`) VALUES
(10, 'tirath', 7869, '2022-12-22-63a483cc89f22.jpg', 1, '2022-12-22 10:50:28', '2022-12-22 10:50:28'),
(13, 'Sonu', 741, '2022-12-22-63a489ffab35b.jpg', 1, '2022-12-22 11:16:55', '2022-12-22 11:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `educations`
--

CREATE TABLE `educations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `class_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `educations`
--

INSERT INTO `educations` (`id`, `class_name`, `created_at`, `updated_at`) VALUES
(1, '1st', '2022-02-16 17:04:41', '2022-02-16 17:04:48'),
(2, '2nd', '2022-02-16 17:04:41', '2022-02-16 17:04:48'),
(3, '3rd', '2022-02-16 17:04:41', '2022-02-16 17:04:48');

-- --------------------------------------------------------

--
-- Stand-in structure for view `getrecord`
-- (See below for the actual view)
--
CREATE TABLE `getrecord` (
`student_name` varchar(150)
,`roll_no` int(11)
,`photo` varchar(200)
,`class_name` varchar(100)
,`total` decimal(32,0)
);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `roll_no` int(11) NOT NULL,
  `education_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `marks` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `roll_no`, `education_id`, `subject_id`, `marks`, `created_at`, `updated_at`) VALUES
(45, 7869, 1, 1, 5, '2022-12-22 10:50:28', '2022-12-22 10:50:28'),
(46, 7869, 1, 2, 6, '2022-12-22 10:50:28', '2022-12-22 10:50:28'),
(47, 7869, 1, 3, 7, '2022-12-22 10:50:28', '2022-12-22 10:50:28'),
(48, 7869, 1, 4, 8, '2022-12-22 10:50:28', '2022-12-22 10:50:28'),
(59, 741, 1, 1, 101, '2022-12-22 11:16:55', '2022-12-22 11:16:55'),
(60, 741, 1, 2, 15, '2022-12-22 11:16:55', '2022-12-22 11:16:55'),
(61, 741, 1, 3, 14, '2022-12-22 11:16:55', '2022-12-22 11:16:55'),
(62, 741, 1, 4, 14, '2022-12-22 11:16:55', '2022-12-22 11:16:55');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_02_15_183848_create_educations_table', 1),
(6, '2022_02_15_184032_create_subjects_table', 1),
(7, '2022_02_15_184340_create_candidates_table', 1),
(8, '2022_02_15_184717_create_marks_table', 1),
(9, '2022_02_18_163642_create_employees_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `education_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_name`, `education_id`, `created_at`, `updated_at`) VALUES
(1, 'Hindi', 1, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(2, 'English', 1, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(3, 'Math', 1, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(4, 'Science', 1, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(5, 'Hindi', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(6, 'English', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(7, 'Math', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(8, 'Science', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(9, 'Social Science ', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(10, 'Sanskrit', 2, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(11, 'Hindi', 3, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(12, 'English', 3, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(13, 'Math', 3, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(14, 'Physics', 3, '2022-02-16 17:04:41', '2022-02-16 17:04:41'),
(15, 'Chemistry', 3, '2022-02-16 17:04:41', '2022-02-16 17:04:41');

-- --------------------------------------------------------

--
-- Structure for view `getrecord`
--
DROP TABLE IF EXISTS `getrecord`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `getrecord`  AS SELECT `c`.`student_name` AS `student_name`, `c`.`roll_no` AS `roll_no`, `c`.`photo` AS `photo`, `e`.`class_name` AS `class_name`, sum(`m`.`marks`) AS `total` FROM ((`candidates` `c` join `marks` `m` on(`m`.`roll_no` = `c`.`roll_no`)) join `educations` `e` on(`e`.`id` = `c`.`education_id`)) WHERE `c`.`education_id` = `m`.`education_id` GROUP BY `m`.`roll_no` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `candidates_roll_no_unique` (`roll_no`),
  ADD KEY `candidates_education_id_foreign` (`education_id`);

--
-- Indexes for table `educations`
--
ALTER TABLE `educations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `marks_education_id_foreign` (`education_id`),
  ADD KEY `marks_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subjects_education_id_foreign` (`education_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `educations`
--
ALTER TABLE `educations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidates`
--
ALTER TABLE `candidates`
  ADD CONSTRAINT `candidates_education_id_foreign` FOREIGN KEY (`education_id`) REFERENCES `educations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `marks_education_id_foreign` FOREIGN KEY (`education_id`) REFERENCES `educations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `marks_subject_id_foreign` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_education_id_foreign` FOREIGN KEY (`education_id`) REFERENCES `educations` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
