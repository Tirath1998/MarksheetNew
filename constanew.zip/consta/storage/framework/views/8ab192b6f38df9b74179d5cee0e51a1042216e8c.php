<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Task - <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.11.4/datatables.min.css" />
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.11.4/datatables.min.js"></script>

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<br>

<body style="background-color: white;">

    <div class="container w3-container">
        <?php echo $__env->yieldContent('content'); ?>

    </div>
</body>
<script src="<?php echo e(asset('js/main.js')); ?>" type="text/javascript"></script>

</html><?php /**PATH E:\xampp\htdocs\consta\resources\views/layouts/master.blade.php ENDPATH**/ ?>