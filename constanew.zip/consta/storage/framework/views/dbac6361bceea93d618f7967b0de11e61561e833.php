<?php $__env->startPush('style'); ?>
<script>
function previewFile(input) {
    var file = $("input[type=file]").get(0).files[0];

    if (file) {
        var reader = new FileReader();

        reader.onload = function() {
            $("#previewImg").attr("src", reader.result);
        }

        reader.readAsDataURL(file);
    }
}
</script>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e("Home"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="w3-container">
  <h2>Student Marksheet</h2>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
  
  <div class="w3-card-4">
    <div class="w3-container w3-green">
      <h2>Student Details</h2>

    </div>
    <h4 style="text-align: right;"><a class="nav-link w3-button w3-black" href="<?php echo e(url('/getstudents')); ?>">Student List</a></h4>
    <form id="saveMarksDetails" class="w3-container">
            <?php echo csrf_field(); ?>
    
      <p>
      <input class="w3-input" type="text" id="sname" name="sname" placeholder="Enter Student Name">
      <span class="text-danger" id="nameError"></span>
      <label>Student Name <span style='color: red;'>*</span></label></p>


      <p>     
      <input class="w3-input" type="text" id="roll_no" name="roll_no" placeholder="Enter Roll No.">
      <span class="text-danger" id="rolNoError"></span>
                                <span id="rollno_response"></span>
      <label>Roll No. <span style='color: red;'>*</span></label></p>

      <p>
          <input type="file" class="w3-input" name="file" id="file" onchange="previewFile(this);">
                                <span class="text-danger" id="photoError"></span>
                                <img src="<?php echo e(asset('images/pngtree-boys-default-avatar-png-image_2854357.jpg')); ?>" id="previewImg" width="152" height="145">
      </p>


      <h4 style="color: black;">Marks Details<h4>
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label>Select Class<span style='color: red;'>*</span></label>
                                    <select id="sclass" class="form-control" name="sclass">
                                        <option value="" selected>Class</option>
                                        <?php if(isset($educations)): ?>
                                        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($edu->id); ?>"><?php echo e($edu->class_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </select>
                                    <span class="text-danger" id="classError"></span>
                                </div>
                            </div>

                            <div class="form-row" id="subjectDiv">

                            </div>


      <a href="javaScript:void(0);" onclick="saveSubjectMarks();" id='submitBtn'
                                class="btn btn-success">Save</a>
    </form>

    <form id="class_filter">
                    <br>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            
                            <select id="class_filter_drop" class="form-control" name="class_filter_drop">
                                <option value="" selected>Select Class</option>
                                <?php if(isset($educations)): ?>
                                <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($edu->id); ?>"><?php echo e($edu->class_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>




                </form>

                <table class="w3-table-all w3-card-4" id="studentMarksdetails">
                    <thead>
                        <tr>
                            
                            <th>Student Name</th>
                            <th>Roll No</th>
                            <!-- <th>Class</th> -->
                            <?php if(isset($subjects)): ?>
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($sub->subject_name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>

                        <?php if(isset($subMarks)): ?>
                        <?php $__currentLoopData = $subMarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1=>$sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td scope="row"><?php echo e($sm['Student Name']); ?></td>
                            <td><?php echo e($sm['Roll No']); ?></td>
                            <!-- <td></td> -->
                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($sm[$sub->subject_name]); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\consta\resources\views/students/index.blade.php ENDPATH**/ ?>