
<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('title'); ?>
<?php echo e("Home"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="w3-container">

  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
  
  <div class="w3-card-4">
    <div class="w3-container w3-green">
      <h2>Authentication</h2>

    </div>
    Auth code is :- #@rd2kr
    
    <form method="post" action="login" class="w3-container">
            <?php echo csrf_field(); ?>
    
      


      <p>     
      <input class="w3-input" type="text" id="password" name="password" placeholder="Enter Auth Code" required="">
      
                              
      </p>

      


      

     

    <input type="submit" name="submit" value="LOGIN" class="btn btn-success">
                                <br><br><br>
    </form>

   
                
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\consta\resources\views//login.blade.php ENDPATH**/ ?>