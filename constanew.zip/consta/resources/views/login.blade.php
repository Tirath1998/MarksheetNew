@extends('layouts.master')
@push('style')

@endpush
@section('title')
{{"Home"}}
@endsection
@section('content')

<div class="w3-container">

  
  @if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
    @endif
  
  <div class="w3-card-4">
    <div class="w3-container w3-green">
      <h2>Authentication</h2>

    </div>
    Auth code is :- #@rd2kr
    
    <form method="post" action="login" class="w3-container">
            @csrf
    
      


      <p>     
      <input class="w3-input" type="text" id="password" name="password" placeholder="Enter Auth Code" required="">
      
                              
      </p>

      


      

     

    <input type="submit" name="submit" value="LOGIN" class="btn btn-success">
                                <br><br><br>
    </form>

   
                
  </div>
</div>

@endsection